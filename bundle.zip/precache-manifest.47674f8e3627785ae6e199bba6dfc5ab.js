self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "998c9339aa4314c3c327ce64a3c3dd46",
    "url": "/index.html"
  },
  {
    "revision": "bd409ca5117b0052dd12",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "59641f79f1ccd2bf2562",
    "url": "/static/css/main.526c3e6a.chunk.css"
  },
  {
    "revision": "bd409ca5117b0052dd12",
    "url": "/static/js/2.4a90f270.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4a90f270.chunk.js.LICENSE.txt"
  },
  {
    "revision": "59641f79f1ccd2bf2562",
    "url": "/static/js/main.e7333d55.chunk.js"
  },
  {
    "revision": "75cfd1fe0bc4c74289d3",
    "url": "/static/js/runtime-main.ceb32b2a.js"
  },
  {
    "revision": "b4a73f38957b8cfa451b1dccebc95c14",
    "url": "/static/media/mask.b4a73f38.svg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);